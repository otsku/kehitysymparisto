var Task = require('../models/Task'); 


exports.task_list = function(req,res,next) { 
    var taskList=[]; 
    Task.getAllTasks(function(err, rows, fields) {  
        if (err) {  
        return next(err); } 
        for (var i = 0; i < rows.length; i++) { 

            // Create an object to save current row's data 
            var task = { 
                'id':rows[i].id,
                'title':rows[i].title,
                'message':rows[i].message, 
            } 
            // Add object into array 
            taskList.push(task); 
        } 

            // Render task.pug page using array  
        res.render('task', {message:'Messages',taskList:taskList}); 
    }); 
}; 

// Handle Task create on GET 

exports.task_create_get = function(req, res, next) {      
    res.render('task_form', { title: 'Luo tehtävä' });
};

// Handle Task create on POST 
exports.task_create_post = function(req, res, next) {
    
    
    //Check that the Title field is not empty
    req.checkBody('title', 'Title is required').notEmpty(); 
    
    //Trim and escape the name field. 
    req.sanitize('title').escape();
    req.sanitize('title').trim();
    
    
    
    //Run the validators
    var errors = req.validationErrors();
    
    var task = 
      { id:'', 
        title: req.body.title, 
        message: req.body.message, 
        status:'pending'
       };
    
    if (errors) {
        //If there are errors render the form again, passing the previously entered values and errors
        res.render('task_form', { title: 'Luo tehtävä', task: task, errors: errors});
    return;
    } 
    else {

        Task.addTask(task,function(err){
            if(err) {return next(err);}
            res.redirect("/Tasks");
        });
        
    }
};